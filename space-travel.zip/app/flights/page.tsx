"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { CalendarIcon, ChevronDown, Filter, Loader2, Rocket } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

// Flight type definition
interface FlightClassOption {
  type: string
  price: number
  availableSeats: number
}

interface Flight {
  id: string
  destination: string
  departureDate: string
  returnDate: string
  price: number
  availableSeats: number
  flightTime: string
  departureLocation: string
  flightNumber: string
  classOptions: FlightClassOption[]
}

export default function FlightsPage() {
  const [date, setDate] = useState<Date>()
  const [selectedDestination, setSelectedDestination] = useState<string>("any")
  const [selectedClass, setSelectedClass] = useState<string>("any")
  const [searchPerformed, setSearchPerformed] = useState(false)
  const [flights, setFlights] = useState<Flight[]>([])
  const [loading, setLoading] = useState(false)
  const [sortOrder, setSortOrder] = useState<string>("price-asc")

  const destinations = [
    { id: "orbital", name: "Orbital Station Alpha", distance: "400 km", duration: "2 hours" },
    { id: "lunar", name: "Lunar Grand Hotel", distance: "384,400 km", duration: "3 days" },
    { id: "mars", name: "Mars Base One", distance: "54.6 million km", duration: "7 months" },
  ]

  const flightClasses = [
    { id: "economy", name: "Economy Class", price: 750000 },
    { id: "luxury", name: "Luxury Class", price: 1200000 },
    { id: "zerog", name: "Zero-G VIP Experience", price: 2500000 },
  ]

  const handleSearch = async () => {
    setLoading(true)
    setSearchPerformed(true)

    try {
      // Build query parameters
      const params = new URLSearchParams()
      if (selectedDestination && selectedDestination !== "any") {
        params.append("destination", selectedDestination)
      }
      if (date) {
        params.append("departureDate", format(date, "yyyy-MM-dd"))
      }
      if (selectedClass && selectedClass !== "any") {
        params.append("class", selectedClass)
      }

      // Fetch flights from API
      const response = await fetch(`/api/flights?${params.toString()}`)
      const data = await response.json()

      // Sort flights based on current sort order
      const sortedFlights = sortFlights(data.flights, sortOrder)
      setFlights(sortedFlights)
    } catch (error) {
      console.error("Error fetching flights:", error)
    } finally {
      setLoading(false)
    }
  }

  const sortFlights = (flightsToSort: Flight[], order: string) => {
    return [...flightsToSort].sort((a, b) => {
      switch (order) {
        case "price-asc":
          return a.price - b.price
        case "price-desc":
          return b.price - a.price
        case "duration-asc":
          return a.flightTime.localeCompare(b.flightTime)
        case "duration-desc":
          return b.flightTime.localeCompare(a.flightTime)
        default:
          return 0
      }
    })
  }

  const handleSort = (order: string) => {
    setSortOrder(order)
    setFlights(sortFlights(flights, order))
  }

  // Initial search on page load
  useEffect(() => {
    handleSearch()
  }, [])

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <Rocket className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Dubai to the Stars</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/flights" className="text-sm font-medium">
              Flights
            </Link>
            <Link href="/accommodations" className="text-sm font-medium">
              Accommodations
            </Link>
            <Link href="/packages" className="text-sm font-medium">
              Packages
            </Link>
            <Link href="/dashboard" className="text-sm font-medium">
              Dashboard
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 hero-gradient text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl bg-clip-text text-transparent bg-gradient-to-r from-white to-uae-green">
                  Book Your Space Flight
                </h1>
                <p className="max-w-[600px] text-white/80 md:text-xl">
                  Search and book your journey to the stars from Dubai
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 uae-pattern-bg">
          <div className="container px-4 md:px-6">
            <Card className="mx-auto max-w-4xl border-primary/20">
              <CardHeader className="border-b border-primary/10">
                <CardTitle>Flight Search</CardTitle>
                <CardDescription>Find your perfect space journey</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <Tabs defaultValue="roundtrip" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="roundtrip">Round Trip</TabsTrigger>
                    <TabsTrigger value="oneway">One Way</TabsTrigger>
                    <TabsTrigger value="multidestination">Multi-Destination</TabsTrigger>
                  </TabsList>
                  <TabsContent value="roundtrip" className="mt-6">
                    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          From
                        </label>
                        <Select defaultValue="dubai">
                          <SelectTrigger>
                            <SelectValue placeholder="Select departure" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="dubai">Dubai Spaceport</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          To
                        </label>
                        <Select value={selectedDestination} onValueChange={setSelectedDestination}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select destination" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="any">Any Destination</SelectItem>
                            {destinations.map((destination) => (
                              <SelectItem key={destination.id} value={destination.name}>
                                {destination.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Departure Date
                        </label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="outline" className="w-full justify-start text-left font-normal">
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {date ? format(date, "PPP") : <span>Pick a date</span>}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={date}
                              onSelect={setDate}
                              initialFocus
                              disabled={(date) => date < new Date()}
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Travel Class
                        </label>
                        <Select value={selectedClass} onValueChange={setSelectedClass}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select class" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="any">Any Class</SelectItem>
                            {flightClasses.map((flightClass) => (
                              <SelectItem key={flightClass.id} value={flightClass.name}>
                                {flightClass.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="mt-6 flex justify-end">
                      <Button onClick={handleSearch} className="bg-primary hover:bg-primary/90">
                        {loading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Searching...
                          </>
                        ) : (
                          "Search Flights"
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                  <TabsContent value="oneway" className="mt-6">
                    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          From
                        </label>
                        <Select defaultValue="dubai">
                          <SelectTrigger>
                            <SelectValue placeholder="Select departure" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="dubai">Dubai Spaceport</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          To
                        </label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select destination" />
                          </SelectTrigger>
                          <SelectContent>
                            {destinations.map((destination) => (
                              <SelectItem key={destination.id} value={destination.id}>
                                {destination.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Departure Date
                        </label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="outline" className="w-full justify-start text-left font-normal">
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              <span>Pick a date</span>
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar mode="single" initialFocus disabled={(date) => date < new Date()} />
                          </PopoverContent>
                        </Popover>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Travel Class
                        </label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select class" />
                          </SelectTrigger>
                          <SelectContent>
                            {flightClasses.map((flightClass) => (
                              <SelectItem key={flightClass.id} value={flightClass.id}>
                                {flightClass.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="mt-6 flex justify-end">
                      <Button onClick={handleSearch} className="bg-primary hover:bg-primary/90">
                        {loading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Searching...
                          </>
                        ) : (
                          "Search Flights"
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                  <TabsContent value="multidestination" className="mt-6">
                    <div className="space-y-4">
                      <div className="grid gap-6 md:grid-cols-3">
                        <div className="space-y-2">
                          <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            From
                          </label>
                          <Select defaultValue="dubai">
                            <SelectTrigger>
                              <SelectValue placeholder="Select departure" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="dubai">Dubai Spaceport</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            To
                          </label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select destination" />
                            </SelectTrigger>
                            <SelectContent>
                              {destinations.map((destination) => (
                                <SelectItem key={destination.id} value={destination.id}>
                                  {destination.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            Date
                          </label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button variant="outline" className="w-full justify-start text-left font-normal">
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                <span>Pick a date</span>
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar mode="single" initialFocus disabled={(date) => date < new Date()} />
                            </PopoverContent>
                          </Popover>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="mt-2">
                        + Add Destination
                      </Button>
                    </div>
                    <div className="mt-6 flex justify-end">
                      <Button onClick={handleSearch} className="bg-primary hover:bg-primary/90">
                        {loading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Searching...
                          </>
                        ) : (
                          "Search Flights"
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <div className="mt-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Available Flights</h2>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Filter className="mr-2 h-4 w-4" />
                      Sort By
                      <ChevronDown className="ml-2 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleSort("price-asc")}>Price: Low to High</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort("price-desc")}>Price: High to Low</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort("duration-asc")}>Duration: Shortest</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleSort("duration-desc")}>Duration: Longest</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <span className="ml-2 text-lg">Searching for flights...</span>
                </div>
              ) : flights.length > 0 ? (
                <div className="grid gap-6">
                  {flights.map((flight) => (
                    <Card key={flight.id} className="overflow-hidden card-hover-effect border-primary/10">
                      <div className="md:flex">
                        <div className="p-6 md:w-2/3">
                          <div className="flex items-center justify-between mb-4">
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="text-xl font-bold">{flight.destination}</h3>
                                <Badge className="bg-secondary text-white">{flight.flightNumber}</Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">Flight Time: {flight.flightTime}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-2xl font-bold text-primary">AED {flight.price.toLocaleString()}</p>
                              <p className="text-sm text-muted-foreground">per person</p>
                            </div>
                          </div>
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div>
                              <p className="text-sm font-medium">Departure: {flight.departureDate}</p>
                              <p className="text-sm font-medium">Return: {flight.returnDate}</p>
                              <p className="text-sm text-muted-foreground mt-2">
                                {flight.availableSeats} seats available
                              </p>
                            </div>
                            <div className="flex flex-col gap-2 sm:items-end">
                              <Select>
                                <SelectTrigger className="w-[180px]">
                                  <SelectValue placeholder="Select class" />
                                </SelectTrigger>
                                <SelectContent>
                                  {flight.classOptions.map((option, index) => (
                                    <SelectItem key={index} value={option.type}>
                                      {option.type} - AED {option.price.toLocaleString()}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <Link href={`/flights/${flight.id}`}>
                                <Button className="bg-primary hover:bg-primary/90">Select Flight</Button>
                              </Link>
                            </div>
                          </div>
                        </div>
                        <div className="md:w-1/3 bg-muted relative min-h-[200px]">
                          <div className="absolute inset-0 bg-[url('/placeholder.svg?height=300&width=300')] bg-cover bg-center"></div>
                          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                            <p className="text-white text-sm font-medium">From Dubai Spaceport</p>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : searchPerformed ? (
                <div className="text-center py-12">
                  <h3 className="text-xl font-bold">No flights found</h3>
                  <p className="text-muted-foreground mt-2">Try adjusting your search criteria</p>
                </div>
              ) : null}
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t border-primary/10 bg-muted/30">
        <div className="container flex flex-col gap-4 py-10 md:flex-row md:gap-8 md:py-12">
          <div className="flex flex-col gap-2 md:gap-4 lg:flex-1">
            <div className="flex items-center gap-2">
              <Rocket className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Dubai to the Stars</span>
            </div>
            <p className="text-sm text-muted-foreground md:text-base">
              The ultimate space travel experience from Dubai to the cosmos.
            </p>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-8 sm:grid-cols-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Press
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Destinations</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Orbital Stations
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Lunar Resorts
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Mars Expeditions
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Travel Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Safety Protocols
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Training
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Cookie Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="border-t border-primary/10 py-6">
          <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-sm text-muted-foreground md:text-left">
              © 2025 Dubai to the Stars. All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <Link href="#" className="text-muted-foreground hover:text-primary">
                <span className="sr-only">Twitter</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary">
                <span className="sr-only">Instagram</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary">
                <span className="sr-only">Facebook</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

