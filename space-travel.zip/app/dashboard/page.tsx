"use client"

import { useState } from "react"
import Link from "next/link"
import { CalendarClock, Clock, Rocket, Settings, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("bookings")

  // Mock data for user bookings
  const bookings = [
    {
      id: "bk001",
      destination: "Orbital Station Alpha",
      departureDate: "2025-06-15",
      returnDate: "2025-06-22",
      status: "Confirmed",
      price: 750000,
      launchCountdown: 180, // days
      seatClass: "Economy Class",
    },
    {
      id: "bk002",
      destination: "Lunar Grand Hotel",
      departureDate: "2025-07-10",
      returnDate: "2025-07-17",
      status: "Pending",
      price: 1500000,
      launchCountdown: 205, // days
      seatClass: "Luxury Class",
    },
  ]

  // Mock data for travel advice
  const travelAdvice = [
    {
      id: "adv001",
      title: "Packing for Zero Gravity",
      description: "Essential items to bring for your zero gravity experience.",
      category: "Packing",
    },
    {
      id: "adv002",
      title: "Space Sickness Prevention",
      description: "Tips to prevent and manage space sickness during your journey.",
      category: "Health",
    },
    {
      id: "adv003",
      title: "Lunar Surface Activities",
      description: "Recommended activities during your stay on the lunar surface.",
      category: "Activities",
    },
    {
      id: "adv004",
      title: "Communication in Space",
      description: "How to stay connected with Earth during your space journey.",
      category: "Communication",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <Rocket className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Dubai to the Stars</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/flights" className="text-sm font-medium">
              Flights
            </Link>
            <Link href="/accommodations" className="text-sm font-medium">
              Accommodations
            </Link>
            <Link href="/packages" className="text-sm font-medium">
              Packages
            </Link>
            <Link href="/dashboard" className="text-sm font-medium">
              Dashboard
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
              <span className="sr-only">Settings</span>
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <div className="container py-12">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/4">
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src="/placeholder.svg?height=64&width=64" alt="User" />
                      <AvatarFallback>JD</AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle>John Doe</CardTitle>
                      <CardDescription>Space Explorer</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-medium">Membership Level</p>
                      <p className="text-sm text-muted-foreground">Platinum Explorer</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Space Miles</p>
                      <p className="text-sm text-muted-foreground">125,000 miles</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Next Tier</p>
                      <div className="mt-2 space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span>Diamond Explorer</span>
                          <span>75%</span>
                        </div>
                        <Progress value={75} className="h-2" />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    <User className="mr-2 h-4 w-4" />
                    Edit Profile
                  </Button>
                </CardFooter>
              </Card>
            </div>
            <div className="md:w-3/4">
              <Tabs defaultValue="bookings" className="w-full" onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="bookings">My Bookings</TabsTrigger>
                  <TabsTrigger value="advice">Travel Advice</TabsTrigger>
                </TabsList>
                <TabsContent value="bookings" className="mt-6">
                  <div className="grid gap-6">
                    {bookings.map((booking) => (
                      <Card key={booking.id}>
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <div>
                              <CardTitle>{booking.destination}</CardTitle>
                              <CardDescription>
                                {booking.departureDate} to {booking.returnDate}
                              </CardDescription>
                            </div>
                            <Badge variant={booking.status === "Confirmed" ? "default" : "outline"}>
                              {booking.status}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="grid gap-4 md:grid-cols-2">
                            <div>
                              <p className="text-sm font-medium">Booking Details</p>
                              <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                                <li>Booking ID: {booking.id}</li>
                                <li>Class: {booking.seatClass}</li>
                                <li>Price: AED {booking.price.toLocaleString()}</li>
                              </ul>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Launch Countdown</p>
                              <div className="mt-2 flex items-center gap-2">
                                <Clock className="h-4 w-4 text-muted-foreground" />
                                <span className="text-2xl font-bold">{booking.launchCountdown}</span>
                                <span className="text-sm text-muted-foreground">days remaining</span>
                              </div>
                              <Progress value={(365 - booking.launchCountdown) / 3.65} className="mt-2 h-2" />
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="flex justify-between">
                          <Button variant="outline">View Details</Button>
                          <Button>Manage Booking</Button>
                        </CardFooter>
                      </Card>
                    ))}
                    {bookings.length === 0 && (
                      <div className="text-center py-12">
                        <CalendarClock className="mx-auto h-12 w-12 text-muted-foreground" />
                        <h3 className="mt-4 text-lg font-medium">No bookings found</h3>
                        <p className="mt-2 text-sm text-muted-foreground">You haven't made any bookings yet.</p>
                        <Button className="mt-4">
                          <Link href="/flights">Book a Flight</Link>
                        </Button>
                      </div>
                    )}
                  </div>
                </TabsContent>
                <TabsContent value="advice" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Space Travel Advice</CardTitle>
                      <CardDescription>Personalized recommendations for your space journey</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-6 md:grid-cols-2">
                        {travelAdvice.map((advice) => (
                          <div key={advice.id} className="space-y-2">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{advice.category}</Badge>
                              <h3 className="font-medium">{advice.title}</h3>
                            </div>
                            <p className="text-sm text-muted-foreground">{advice.description}</p>
                            <Button variant="link" className="p-0 h-auto">
                              Read more
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="mt-6">
                    <CardHeader>
                      <CardTitle>Recommended Packing List</CardTitle>
                      <CardDescription>Essential items for your space journey</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-6 md:grid-cols-2">
                        <div>
                          <h3 className="font-medium mb-2">Clothing</h3>
                          <ul className="space-y-1 text-sm">
                            <li className="flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                              Compression garments (3 sets)
                            </li>
                            <li className="flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                              Lightweight, breathable clothing
                            </li>
                            <li className="flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                              Anti-radiation underwear
                            </li>
                            <li className="flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                              Slip-on shoes with secure straps
                            </li>
                          </ul>
                        </div>
                        <div>
                          <h3 className="font-medium mb-2">Personal Items</h3>
                          <ul className="space-y-1 text-sm">
                            <li className="flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                              Space-approved toiletries
                            </li>
                            <li className="flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                              Anti-nausea medication
                            </li>
                            <li className="flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                              Digital entertainment device
                            </li>
                            <li className="flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                              Space-certified camera
                            </li>
                          </ul>
                        </div>
                      </div>
                      <Separator className="my-4" />
                      <div>
                        <h3 className="font-medium mb-2">Important Notes</h3>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          <li>All luggage must be under 15kg due to launch weight restrictions</li>
                          <li>Electronic devices must be approved for space travel</li>
                          <li>Liquids are limited to 100ml containers in a sealed bag</li>
                          <li>All medications must be declared before departure</li>
                        </ul>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button variant="outline" className="w-full">
                        Download Complete Packing Guide
                      </Button>
                    </CardFooter>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      <footer className="border-t">
        <div className="container flex flex-col gap-4 py-10 md:flex-row md:gap-8 md:py-12">
          <div className="flex flex-col gap-2 md:gap-4 lg:flex-1">
            <div className="flex items-center gap-2">
              <Rocket className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Dubai to the Stars</span>
            </div>
            <p className="text-sm text-muted-foreground md:text-base">
              The ultimate space travel experience from Dubai to the cosmos.
            </p>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-8 sm:grid-cols-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Press
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Destinations</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Orbital Stations
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Lunar Resorts
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Mars Expeditions
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Travel Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Safety Protocols
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Training
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Cookie Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

