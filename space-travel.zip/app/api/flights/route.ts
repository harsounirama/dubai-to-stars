import { NextResponse } from "next/server"

// This simulates a database of flights
const flightsDatabase = [
  {
    id: "fl001",
    destination: "Orbital Station Alpha",
    departureDate: "2025-06-15",
    returnDate: "2025-06-22",
    price: 750000,
    availableSeats: 12,
    flightTime: "2 hours",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-001",
    classOptions: [
      { type: "Economy Class", price: 750000, availableSeats: 8 },
      { type: "Luxury Class", price: 1200000, availableSeats: 3 },
      { type: "Zero-G VIP Experience", price: 2500000, availableSeats: 1 },
    ],
  },
  {
    id: "fl002",
    destination: "Orbital Station Alpha",
    departureDate: "2025-06-20",
    returnDate: "2025-06-27",
    price: 750000,
    availableSeats: 8,
    flightTime: "2 hours",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-002",
    classOptions: [
      { type: "Economy Class", price: 750000, availableSeats: 5 },
      { type: "Luxury Class", price: 1200000, availableSeats: 2 },
      { type: "Zero-G VIP Experience", price: 2500000, availableSeats: 1 },
    ],
  },
  {
    id: "fl003",
    destination: "Lunar Grand Hotel",
    departureDate: "2025-07-10",
    returnDate: "2025-07-17",
    price: 1500000,
    availableSeats: 6,
    flightTime: "3 days",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-003",
    classOptions: [
      { type: "Economy Class", price: 1500000, availableSeats: 3 },
      { type: "Luxury Class", price: 2200000, availableSeats: 2 },
      { type: "Zero-G VIP Experience", price: 3500000, availableSeats: 1 },
    ],
  },
  {
    id: "fl004",
    destination: "Mars Base One",
    departureDate: "2025-09-01",
    returnDate: "2026-04-01",
    price: 3500000,
    availableSeats: 4,
    flightTime: "7 months",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-004",
    classOptions: [
      { type: "Economy Class", price: 3500000, availableSeats: 2 },
      { type: "Luxury Class", price: 5200000, availableSeats: 1 },
      { type: "Zero-G VIP Experience", price: 7500000, availableSeats: 1 },
    ],
  },
  {
    id: "fl005",
    destination: "Orbital Station Beta",
    departureDate: "2025-07-05",
    returnDate: "2025-07-12",
    price: 780000,
    availableSeats: 10,
    flightTime: "2.5 hours",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-005",
    classOptions: [
      { type: "Economy Class", price: 780000, availableSeats: 6 },
      { type: "Luxury Class", price: 1250000, availableSeats: 3 },
      { type: "Zero-G VIP Experience", price: 2600000, availableSeats: 1 },
    ],
  },
  {
    id: "fl006",
    destination: "Lunar Grand Hotel",
    departureDate: "2025-08-15",
    returnDate: "2025-08-22",
    price: 1550000,
    availableSeats: 5,
    flightTime: "3 days",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-006",
    classOptions: [
      { type: "Economy Class", price: 1550000, availableSeats: 3 },
      { type: "Luxury Class", price: 2300000, availableSeats: 1 },
      { type: "Zero-G VIP Experience", price: 3600000, availableSeats: 1 },
    ],
  },
  {
    id: "fl007",
    destination: "Orbital Station Alpha",
    departureDate: "2025-07-01",
    returnDate: "2025-07-08",
    price: 760000,
    availableSeats: 9,
    flightTime: "2 hours",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-007",
    classOptions: [
      { type: "Economy Class", price: 760000, availableSeats: 6 },
      { type: "Luxury Class", price: 1220000, availableSeats: 2 },
      { type: "Zero-G VIP Experience", price: 2550000, availableSeats: 1 },
    ],
  },
  {
    id: "fl008",
    destination: "Mars Base One",
    departureDate: "2025-10-15",
    returnDate: "2026-05-15",
    price: 3600000,
    availableSeats: 3,
    flightTime: "7 months",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-008",
    classOptions: [
      { type: "Economy Class", price: 3600000, availableSeats: 1 },
      { type: "Luxury Class", price: 5300000, availableSeats: 1 },
      { type: "Zero-G VIP Experience", price: 7600000, availableSeats: 1 },
    ],
  },
  {
    id: "fl009",
    destination: "Orbital Station Gamma",
    departureDate: "2025-08-01",
    returnDate: "2025-08-08",
    price: 790000,
    availableSeats: 11,
    flightTime: "2.2 hours",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-009",
    classOptions: [
      { type: "Economy Class", price: 790000, availableSeats: 7 },
      { type: "Luxury Class", price: 1270000, availableSeats: 3 },
      { type: "Zero-G VIP Experience", price: 2650000, availableSeats: 1 },
    ],
  },
  {
    id: "fl010",
    destination: "Lunar Exploration Base",
    departureDate: "2025-09-20",
    returnDate: "2025-09-27",
    price: 1600000,
    availableSeats: 4,
    flightTime: "3.2 days",
    departureLocation: "Dubai Spaceport",
    flightNumber: "DST-010",
    classOptions: [
      { type: "Economy Class", price: 1600000, availableSeats: 2 },
      { type: "Luxury Class", price: 2350000, availableSeats: 1 },
      { type: "Zero-G VIP Experience", price: 3650000, availableSeats: 1 },
    ],
  },
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)

  // Get filter parameters
  const destination = searchParams.get("destination")
  const departureDate = searchParams.get("departureDate")
  const travelClass = searchParams.get("class")

  // Filter flights based on search parameters
  let filteredFlights = [...flightsDatabase]

  if (destination && destination !== "any") {
    filteredFlights = filteredFlights.filter((flight) =>
      flight.destination.toLowerCase().includes(destination.toLowerCase()),
    )
  }

  if (departureDate) {
    filteredFlights = filteredFlights.filter((flight) => flight.departureDate === departureDate)
  }

  if (travelClass && travelClass !== "any") {
    filteredFlights = filteredFlights.filter((flight) =>
      flight.classOptions.some(
        (option) => option.type.toLowerCase().includes(travelClass.toLowerCase()) && option.availableSeats > 0,
      ),
    )
  }

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  return NextResponse.json({ flights: filteredFlights })
}

