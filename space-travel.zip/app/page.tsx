import Link from "next/link"
import { ArrowRight, Rocket, Star } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Rocket className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">Dubai to the Stars</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/flights" className="text-sm font-medium">
              Flights
            </Link>
            <Link href="/accommodations" className="text-sm font-medium">
              Accommodations
            </Link>
            <Link href="/packages" className="text-sm font-medium">
              Packages
            </Link>
            <Link href="/dashboard" className="text-sm font-medium">
              Dashboard
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                Sign In
              </Button>
            </Link>
            <Link href="/flights">
              <Button size="sm" className="bg-primary hover:bg-primary/90">
                Book Now
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 hero-gradient text-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none bg-clip-text text-transparent bg-gradient-to-r from-white to-uae-green">
                    Dubai to the Stars
                  </h1>
                  <p className="max-w-[600px] text-white/80 md:text-xl">
                    Experience the ultimate space travel journey. Book your flight to space stations, lunar hotels, and
                    beyond.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/flights">
                    <Button size="lg" className="bg-primary hover:bg-primary/90">
                      Book Your Journey
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/packages">
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-secondary bg-secondary/10 text-secondary hover:bg-secondary/20 hover:text-white"
                    >
                      Explore Packages
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="relative h-[300px] md:h-[400px] lg:h-[500px] xl:h-[600px] rounded-xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-black/20 to-black/0">
                  <div className="absolute inset-0 bg-[url('/placeholder.svg?height=600&width=800')] bg-cover bg-center">
                    <div className="absolute inset-0 bg-black/40"></div>
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 right-4 p-4 bg-black/60 backdrop-blur-sm rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-bold">Lunar Resort Experience</h3>
                      <p className="text-sm text-white/70">Starting from AED 1,500,000</p>
                    </div>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 fill-secondary text-secondary" />
                      <Star className="h-4 w-4 fill-secondary text-secondary" />
                      <Star className="h-4 w-4 fill-secondary text-secondary" />
                      <Star className="h-4 w-4 fill-secondary text-secondary" />
                      <Star className="h-4 w-4 fill-secondary text-secondary" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted uae-pattern-bg">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Popular Destinations</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Explore our most sought-after space destinations
                </p>
              </div>
            </div>
            <div className="flex overflow-x-auto pb-6 pt-6 snap-x snap-mandatory scrollbar-hide space-x-6 px-4 md:px-0">
              <div className="flex flex-col justify-center space-y-4 card-hover-effect min-w-[280px] md:min-w-[320px] snap-start">
                <div className="overflow-hidden rounded-lg">
                  <img
                    src="/placeholder.svg?height=350&width=350"
                    width={350}
                    height={350}
                    alt="Orbital Station Alpha"
                    className="aspect-square object-cover transition-all hover:scale-105"
                  />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Orbital Station Alpha</h3>
                  <p className="text-sm text-muted-foreground">
                    Experience zero gravity luxury in Earth's orbit with panoramic views of our planet.
                  </p>
                </div>
              </div>
              <div className="flex flex-col justify-center space-y-4 card-hover-effect min-w-[280px] md:min-w-[320px] snap-start">
                <div className="overflow-hidden rounded-lg">
                  <img
                    src="/placeholder.svg?height=350&width=350"
                    width={350}
                    height={350}
                    alt="Lunar Grand Hotel"
                    className="aspect-square object-cover transition-all hover:scale-105"
                  />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Lunar Grand Hotel</h3>
                  <p className="text-sm text-muted-foreground">
                    The first luxury hotel on the Moon with Earth views and lunar excursions.
                  </p>
                </div>
              </div>
              <div className="flex flex-col justify-center space-y-4 card-hover-effect min-w-[280px] md:min-w-[320px] snap-start">
                <div className="overflow-hidden rounded-lg">
                  <img
                    src="/placeholder.svg?height=350&width=350"
                    width={350}
                    height={350}
                    alt="Mars Base One"
                    className="aspect-square object-cover transition-all hover:scale-105"
                  />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Mars Base One</h3>
                  <p className="text-sm text-muted-foreground">
                    Be among the first to visit the red planet with our exclusive Mars expedition packages.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Travel Classes</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Choose from our range of luxurious travel experiences
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4 p-6 bg-background rounded-lg shadow-lg border border-primary/10 card-hover-effect">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Economy Class</h3>
                  <p className="text-sm text-muted-foreground">
                    Comfortable seating with essential amenities for your journey to space.
                  </p>
                  <p className="text-2xl font-bold text-primary">AED 750,000</p>
                </div>
                <Link href="/flights">
                  <Button className="w-full bg-primary hover:bg-primary/90">Select</Button>
                </Link>
              </div>
              <div className="flex flex-col justify-center space-y-4 p-6 bg-primary/5 rounded-lg shadow-lg border border-primary card-hover-effect">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Luxury Class</h3>
                  <p className="text-sm text-muted-foreground">
                    Premium seating with enhanced comfort and exclusive services.
                  </p>
                  <p className="text-2xl font-bold text-primary">AED 1,200,000</p>
                </div>
                <Link href="/flights">
                  <Button className="w-full bg-primary hover:bg-primary/90">Select</Button>
                </Link>
              </div>
              <div className="flex flex-col justify-center space-y-4 p-6 bg-background rounded-lg shadow-lg border border-primary/10 card-hover-effect">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">Zero-G VIP Experience</h3>
                  <p className="text-sm text-muted-foreground">
                    Ultimate luxury with private cabin and personalized service.
                  </p>
                  <p className="text-2xl font-bold text-primary">AED 2,500,000</p>
                </div>
                <Link href="/flights">
                  <Button className="w-full bg-primary hover:bg-primary/90">Select</Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t border-primary/10 bg-muted/30">
        <div className="container flex flex-col gap-4 py-10 md:flex-row md:gap-8 md:py-12">
          <div className="flex flex-col gap-2 md:gap-4 lg:flex-1">
            <div className="flex items-center gap-2">
              <Rocket className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Dubai to the Stars</span>
            </div>
            <p className="text-sm text-muted-foreground md:text-base">
              The ultimate space travel experience from Dubai to the cosmos.
            </p>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-8 sm:grid-cols-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Press
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Destinations</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Orbital Stations
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Lunar Resorts
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Mars Expeditions
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Travel Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Safety Protocols
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Training
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Cookie Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="border-t border-primary/10 py-6">
          <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-sm text-muted-foreground md:text-left">
              © 2025 Dubai to the Stars. All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <Link href="#" className="text-muted-foreground hover:text-primary">
                <span className="sr-only">Twitter</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary">
                <span className="sr-only">Instagram</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary">
                <span className="sr-only">Facebook</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

