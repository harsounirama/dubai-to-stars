"use client"

import { useState } from "react"
import Link from "next/link"
import { CalendarIcon, Filter, Rocket, Star } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"

export default function AccommodationsPage() {
  const [date, setDate] = useState<Date>()
  const [priceRange, setPriceRange] = useState([500000, 5000000])
  const [searchPerformed, setSearchPerformed] = useState(false)

  const handleSearch = () => {
    setSearchPerformed(true)
  }

  // Mock data for accommodations
  const accommodations = [
    {
      id: "acc001",
      name: "Orbital Station Alpha - Luxury Suite",
      location: "Low Earth Orbit",
      price: 750000,
      rating: 4.8,
      amenities: ["Zero-G Lounge", "Earth View Windows", "Private Quarters", "Gourmet Dining"],
      description: "Experience luxury in orbit with panoramic views of Earth and state-of-the-art facilities.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "acc002",
      name: "Lunar Grand Hotel - Crater View Room",
      location: "Sea of Tranquility, Moon",
      price: 1200000,
      rating: 4.9,
      amenities: ["Low-G Spa", "Lunar Excursions", "Observation Dome", "Regolith Gardens"],
      description: "The first luxury hotel on the Moon with Earth views and exclusive lunar excursions.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "acc003",
      name: "Mars Base One - Explorer Suite",
      location: "Olympus Mons, Mars",
      price: 3500000,
      rating: 4.7,
      amenities: ["Mars Rover Tours", "Terraforming Lab", "Red Planet Observatory", "Martian Garden"],
      description: "Be among the first to experience luxury accommodation on the red planet.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "acc004",
      name: "Orbital Station Alpha - Standard Room",
      location: "Low Earth Orbit",
      price: 500000,
      rating: 4.5,
      amenities: ["Shared Zero-G Lounge", "Earth View Windows", "Compact Quarters"],
      description: "Affordable orbital accommodation with all the essential amenities for space travelers.",
      image: "/placeholder.svg?height=300&width=500",
    },
  ]

  const filteredAccommodations = searchPerformed
    ? accommodations.filter((acc) => acc.price >= priceRange[0] && acc.price <= priceRange[1])
    : accommodations

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <Rocket className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Dubai to the Stars</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/flights" className="text-sm font-medium">
              Flights
            </Link>
            <Link href="/accommodations" className="text-sm font-medium">
              Accommodations
            </Link>
            <Link href="/packages" className="text-sm font-medium">
              Packages
            </Link>
            <Link href="/dashboard" className="text-sm font-medium">
              Dashboard
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-black text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl bg-clip-text text-transparent bg-gradient-to-r from-white to-primary">
                  Space Accommodations
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">Find your perfect stay among the stars</p>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12">
          <div className="container px-4 md:px-6">
            <Card className="mx-auto max-w-4xl">
              <CardHeader>
                <CardTitle>Find Accommodations</CardTitle>
                <CardDescription>Search for the perfect space stay</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                      Destination
                    </label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select destination" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="orbital">Orbital Stations</SelectItem>
                        <SelectItem value="lunar">Lunar Resorts</SelectItem>
                        <SelectItem value="mars">Mars Bases</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                      Check-in Date
                    </label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {date ? format(date, "PPP") : <span>Pick a date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={setDate}
                          initialFocus
                          disabled={(date) => date < new Date()}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                      Guests
                    </label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Number of guests" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Guest</SelectItem>
                        <SelectItem value="2">2 Guests</SelectItem>
                        <SelectItem value="3">3 Guests</SelectItem>
                        <SelectItem value="4">4 Guests</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                      Duration
                    </label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Length of stay" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3">3 Days</SelectItem>
                        <SelectItem value="7">7 Days</SelectItem>
                        <SelectItem value="14">14 Days</SelectItem>
                        <SelectItem value="30">30 Days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="mt-6 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium leading-none">Price Range (AED)</label>
                    <span className="text-sm text-muted-foreground">
                      {priceRange[0].toLocaleString()} - {priceRange[1].toLocaleString()}
                    </span>
                  </div>
                  <Slider
                    defaultValue={[500000, 5000000]}
                    max={5000000}
                    min={100000}
                    step={100000}
                    value={priceRange}
                    onValueChange={setPriceRange}
                  />
                </div>
                <div className="mt-6 flex justify-end">
                  <Button onClick={handleSearch}>Search Accommodations</Button>
                </div>
              </CardContent>
            </Card>

            <div className="mt-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Available Accommodations</h2>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Filter className="mr-2 h-4 w-4" />
                      Sort By
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>Price: Low to High</DropdownMenuItem>
                    <DropdownMenuItem>Price: High to Low</DropdownMenuItem>
                    <DropdownMenuItem>Rating: Highest First</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredAccommodations.map((accommodation) => (
                  <Card key={accommodation.id} className="overflow-hidden">
                    <div className="aspect-video relative">
                      <img
                        src={accommodation.image || "/placeholder.svg"}
                        alt={accommodation.name}
                        className="object-cover w-full h-full"
                      />
                      <div className="absolute top-2 right-2">
                        <Badge className="flex items-center gap-1 bg-black/70 hover:bg-black/70">
                          <Star className="h-3 w-3 fill-primary text-primary" />
                          {accommodation.rating}
                        </Badge>
                      </div>
                    </div>
                    <CardHeader>
                      <CardTitle>{accommodation.name}</CardTitle>
                      <CardDescription>{accommodation.location}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground mb-4">{accommodation.description}</p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {accommodation.amenities.map((amenity, index) => (
                          <Badge key={index} variant="outline">
                            {amenity}
                          </Badge>
                        ))}
                      </div>
                      <div className="text-xl font-bold">
                        AED {accommodation.price.toLocaleString()}
                        <span className="text-sm font-normal text-muted-foreground"> / week</span>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">View Details</Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>

              {filteredAccommodations.length === 0 && (
                <div className="text-center py-12">
                  <h3 className="text-xl font-bold">No accommodations found</h3>
                  <p className="text-muted-foreground mt-2">Try adjusting your search criteria</p>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t">
        <div className="container flex flex-col gap-4 py-10 md:flex-row md:gap-8 md:py-12">
          <div className="flex flex-col gap-2 md:gap-4 lg:flex-1">
            <div className="flex items-center gap-2">
              <Rocket className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Dubai to the Stars</span>
            </div>
            <p className="text-sm text-muted-foreground md:text-base">
              The ultimate space travel experience from Dubai to the cosmos.
            </p>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-8 sm:grid-cols-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Press
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Destinations</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Orbital Stations
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Lunar Resorts
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Mars Expeditions
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Travel Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Safety Protocols
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Training
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Cookie Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

