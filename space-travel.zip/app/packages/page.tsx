"use client"

import { useState } from "react"
import Link from "next/link"
import { Check, Rocket, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

export default function PackagesPage() {
  const [selectedTab, setSelectedTab] = useState("orbital")

  // Mock data for packages
  const packages = {
    orbital: [
      {
        id: "pkg001",
        name: "Orbital Weekend Getaway",
        description: "A quick weekend escape to experience zero gravity and Earth views.",
        price: 950000,
        duration: "3 days",
        highlights: ["Zero-G experience", "Earth observation deck", "Space photography session", "Gourmet space food"],
        includes: [
          "Round-trip space flight",
          "Accommodation in Orbital Station Alpha",
          "All meals and beverages",
          "Guided activities",
          "Space suit rental",
        ],
        rating: 4.8,
        image: "/placeholder.svg?height=300&width=500",
      },
      {
        id: "pkg002",
        name: "Orbital Luxury Week",
        description: "A full week of luxury in Earth's orbit with premium amenities and exclusive experiences.",
        price: 1750000,
        duration: "7 days",
        highlights: [
          "Private zero-G suite",
          "Space walk experience",
          "Private dining with Earth view",
          "Space photography masterclass",
        ],
        includes: [
          "Round-trip space flight in Luxury Class",
          "Premium accommodation in Orbital Station Alpha",
          "All gourmet meals and premium beverages",
          "Private guided activities",
          "Custom-fitted space suit",
        ],
        rating: 4.9,
        image: "/placeholder.svg?height=300&width=500",
      },
    ],
    lunar: [
      {
        id: "pkg003",
        name: "Lunar Explorer",
        description: "Experience the Moon's surface with guided excursions and luxury accommodation.",
        price: 3500000,
        duration: "10 days",
        highlights: [
          "Lunar surface excursions",
          "Visit to Apollo landing sites",
          "Low-gravity sports",
          "Earth-rise viewing",
        ],
        includes: [
          "Round-trip space flight to the Moon",
          "Luxury accommodation in Lunar Grand Hotel",
          "All meals and beverages",
          "Guided lunar excursions",
          "Lunar rover rides",
        ],
        rating: 4.9,
        image: "/placeholder.svg?height=300&width=500",
      },
      {
        id: "pkg004",
        name: "Lunar Honeymoon",
        description: "The ultimate romantic getaway on the lunar surface with private experiences.",
        price: 4500000,
        duration: "14 days",
        highlights: [
          "Private lunar suite with Earth view",
          "Romantic dinner on the lunar surface",
          "Couple's low-gravity spa treatment",
          "Private lunar excursion",
        ],
        includes: [
          "Round-trip space flight in Zero-G VIP Experience",
          "Premium suite in Lunar Grand Hotel",
          "All gourmet meals and premium beverages",
          "Private guided activities",
          "Commemorative lunar photographs",
        ],
        rating: 5.0,
        image: "/placeholder.svg?height=300&width=500",
      },
    ],
    mars: [
      {
        id: "pkg005",
        name: "Mars Pioneer Expedition",
        description: "Be among the first humans to experience the red planet with this exclusive package.",
        price: 7500000,
        duration: "1 year",
        highlights: [
          "Mars surface exploration",
          "Visit to Olympus Mons",
          "Martian canyon trek",
          "Scientific research participation",
        ],
        includes: [
          "Round-trip space flight to Mars",
          "Accommodation in Mars Base One",
          "All meals and life support",
          "Mars rover expeditions",
          "Scientific training program",
        ],
        rating: 4.7,
        image: "/placeholder.svg?height=300&width=500",
      },
    ],
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <Rocket className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Dubai to the Stars</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/flights" className="text-sm font-medium">
              Flights
            </Link>
            <Link href="/accommodations" className="text-sm font-medium">
              Accommodations
            </Link>
            <Link href="/packages" className="text-sm font-medium">
              Packages
            </Link>
            <Link href="/dashboard" className="text-sm font-medium">
              Dashboard
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-black text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl bg-clip-text text-transparent bg-gradient-to-r from-white to-primary">
                  Space Travel Packages
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">All-inclusive journeys to the cosmos</p>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12">
          <div className="container px-4 md:px-6">
            <Tabs defaultValue="orbital" className="w-full" onValueChange={setSelectedTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="orbital">Orbital Packages</TabsTrigger>
                <TabsTrigger value="lunar">Lunar Packages</TabsTrigger>
                <TabsTrigger value="mars">Mars Packages</TabsTrigger>
              </TabsList>
              {Object.keys(packages).map((destination) => (
                <TabsContent key={destination} value={destination} className="mt-6">
                  <div className="grid gap-6 lg:grid-cols-2">
                    {packages[destination].map((pkg) => (
                      <Card key={pkg.id} className="overflow-hidden">
                        <div className="aspect-video relative">
                          <img
                            src={pkg.image || "/placeholder.svg"}
                            alt={pkg.name}
                            className="object-cover w-full h-full"
                          />
                          <div className="absolute top-2 right-2">
                            <Badge className="flex items-center gap-1 bg-black/70 hover:bg-black/70">
                              <Star className="h-3 w-3 fill-primary text-primary" />
                              {pkg.rating}
                            </Badge>
                          </div>
                        </div>
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <div>
                              <CardTitle>{pkg.name}</CardTitle>
                              <CardDescription>{pkg.duration}</CardDescription>
                            </div>
                            <Badge variant="outline" className="text-primary border-primary">
                              Featured
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-4">{pkg.description}</p>
                          <div className="space-y-4">
                            <div>
                              <h4 className="font-medium mb-2">Highlights</h4>
                              <ul className="grid grid-cols-2 gap-x-4 gap-y-1">
                                {pkg.highlights.map((highlight, index) => (
                                  <li key={index} className="flex items-center gap-2 text-sm">
                                    <Check className="h-4 w-4 text-primary" />
                                    {highlight}
                                  </li>
                                ))}
                              </ul>
                            </div>
                            <Separator />
                            <div>
                              <h4 className="font-medium mb-2">Package Includes</h4>
                              <ul className="space-y-1">
                                {pkg.includes.map((item, index) => (
                                  <li key={index} className="flex items-center gap-2 text-sm">
                                    <Check className="h-4 w-4 text-primary" />
                                    {item}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="flex items-center justify-between">
                          <div className="text-xl font-bold">
                            AED {pkg.price.toLocaleString()}
                            <span className="text-sm font-normal text-muted-foreground"> per person</span>
                          </div>
                          <Button>Book Package</Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-10">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Why Choose Our Packages</h2>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  All-inclusive luxury space travel experiences
                </p>
              </div>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>All-Inclusive Experience</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Our packages include everything from transportation to accommodation, meals, and activities, so you
                    can focus on enjoying your space journey.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Expert Guidance</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Travel with experienced astronauts and space tourism experts who will guide you through every aspect
                    of your journey.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Luxury Accommodations</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Stay in state-of-the-art space habitats designed for comfort and luxury, with breathtaking views of
                    space.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Exclusive Activities</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Experience unique activities only available in space, from spacewalks to lunar rover expeditions.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Safety First</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Your safety is our priority, with rigorous training programs and state-of-the-art safety protocols.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Lifetime Memories</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Create unforgettable memories with experiences that few humans have ever had the opportunity to
                    enjoy.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t">
        <div className="container flex flex-col gap-4 py-10 md:flex-row md:gap-8 md:py-12">
          <div className="flex flex-col gap-2 md:gap-4 lg:flex-1">
            <div className="flex items-center gap-2">
              <Rocket className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Dubai to the Stars</span>
            </div>
            <p className="text-sm text-muted-foreground md:text-base">
              The ultimate space travel experience from Dubai to the cosmos.
            </p>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-8 sm:grid-cols-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Press
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Destinations</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Orbital Stations
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Lunar Resorts
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Mars Expeditions
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Travel Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Safety Protocols
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Training
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground transition-colors hover:text-foreground">
                    Cookie Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="border-t py-6">
          <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-sm text-muted-foreground md:text-left">
              © 2025 Dubai to the Stars. All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">Twitter</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">Instagram</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">Facebook</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

